﻿Clear-Host

#Lecture d'un fichier CSV

#Nom du fichier manipulé
$fCsv ="c:\temp\CSVoutput.csv"

#Création de la collection d'objet
$csv = Import-Csv -path $FCsv -delimiter "," -Encoding Default

foreach ($line in $csv)
{
	$Prenom = "Prénom="    + $line.sPrenom + " "
	$Nom  = "Nom="         + $line.sNom 
	Write-Host $Prenom $Nom
}
